/*
 * Copyright (c) 2006-2018, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 */

#ifndef DRV_RTC_H__
#define DRV_RTC_H__

int wm_hw_rtc_init(void);

#endif
